﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entites
{
    public class MTTEntites
    {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public DateTime DOJ { get; set; }
        public double Salary { get; set; }
        public string Address { get; set; }
    }
}
