﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Route.Entity;
using Route.Exceptions;
using Route.BusinessLayer;

namespace Route.PresentationLayer//Presentation Layer
{
    class RoutePL
    {

        private static void PrintMenu()//PrintMenu
        {
            Console.WriteLine("\n------------------PMPML Route Details-----------------");
            Console.WriteLine("1. Add Route");//Serialization is always called here
            Console.WriteLine("2. Search Route by ID");
            Console.WriteLine("3. Update Route");
            Console.WriteLine("4. Delete Route");
            Console.WriteLine("5. Exit");
           // Console.WriteLine("6. Exit");
            Console.WriteLine("6. Deserialize");
            Console.WriteLine("---------------------------------------------------------\n");

        }

        private static void AddRoute()//Add Route by taking input from user
        {
            try
            {
                RouteDetails newRoute = new RouteDetails();
                Console.WriteLine("Enter RouteID :");
                newRoute.RouteId = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Route From :");
                newRoute.RouteFrom =Console.ReadLine();
                Console.WriteLine("Enter Route To :");
                newRoute.RouteTo = Console.ReadLine();
                Console.WriteLine("Enter Bus Number :");
                newRoute.BusNo = Console.ReadLine();
                Console.WriteLine("Enter Bus Type AC or Non-AC only :");
                newRoute.BusType = Console.ReadLine();
                Console.WriteLine("Enter Bus Capacity :");
                newRoute.Capacity = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Bus Fare :");
                newRoute.Fare = Convert.ToInt32(Console.ReadLine());
                bool routeAdded = RouteBL.AddRouteBL(newRoute);
                if (routeAdded)
                {
                    Console.WriteLine("Route Added");
                    Serialization();//Serialization is Always called here
                }
                else
                    Console.WriteLine("Route not Added");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
          
        }

        private static void DeleteRoute()//Delete Route by taking input from user
        {
            try
            {
                int deleteRouteID;
                Console.WriteLine("Enter Route ID to Delete:");
                deleteRouteID = Convert.ToInt32(Console.ReadLine());
                RouteDetails deleteRoute = RouteBL.SearchRouteBL(deleteRouteID);
                if (deleteRoute != null)
                {
                    bool guestdeleted = RouteBL.DeleteRouteBL(deleteRouteID);
                    if (guestdeleted)
                        Console.WriteLine("Route Deleted");
                    else
                        Console.WriteLine("Route not Deleted ");
                }
                else
                {
                    Console.WriteLine("No Route Details Available");
                }


            }
            catch (RouteExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void UpdateRoute()//Update Route by taking input from user
        {
            try
            {
                int updateRouteID;
                Console.WriteLine("Enter Route ID to Update Details:");
                updateRouteID = Convert.ToInt32(Console.ReadLine());
                RouteDetails updatedRoute = RouteBL.SearchRouteBL(updateRouteID);
                if (updatedRoute != null)
                {
                    Console.WriteLine("Enter Route From :");
                    updatedRoute.RouteFrom = Console.ReadLine();
                    Console.WriteLine("Enter Route To :");
                    updatedRoute.RouteTo = Console.ReadLine();
                    Console.WriteLine("Enter Bus Number :");
                    updatedRoute.BusNo = Console.ReadLine();
                    Console.WriteLine("Enter Bus Type AC or Non-AC only :");
                    updatedRoute.BusType = Console.ReadLine();
                    Console.WriteLine("Enter Bus Capacity :");
                    updatedRoute.Capacity = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Bus Fare :");
                    updatedRoute.Fare = Convert.ToInt32(Console.ReadLine());



                    bool routeUpdated = RouteBL.UpdateRouteBL(updatedRoute);
                    if (routeUpdated)
                        Console.WriteLine("Route Details Updated");
                    else
                        Console.WriteLine("Route Details not Updated ");
                }
                else
                {
                    Console.WriteLine("No Route Details Available");
                }


            }
            catch (RouteExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchRouteByID()//Search Route by taking input from user
        {
            try
            {
                int searchRouteID;
                Console.WriteLine("Enter Route ID to Search:");
                searchRouteID = Convert.ToInt32(Console.ReadLine());
                RouteDetails searchRoute = RouteBL.SearchRouteBL(searchRouteID);
                if (searchRoute != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("RouteID : {0} \n Route From : {1} \n Route To : {2}\n Bus Number : {3} \n Bus Type : {4} \n Capacity {5} \n Fare {6}\n",searchRoute.RouteId,searchRoute.RouteFrom,searchRoute.RouteTo,searchRoute.BusNo,searchRoute.BusType,searchRoute.Capacity,searchRoute.Fare);

                }
                else
                {
                    Console.WriteLine("No Route Details Available");
                }

            }
            catch (RouteExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void Serialization()//Serialization
        {
            bool route = RouteBL.SerializationBL();
            if (route == true)
            {
                Console.WriteLine("\n---------Binary Serialization Done----------------\n");
            }
            else
            {
                Console.WriteLine("\n---------Binary Serialization Failed----------------\n");
            }
        }

        private static void Deserialization()//Deserialization
        {
            try
            {
                List<RouteDetails> objroutelist = RouteBL.DeserializationBL();
                objroutelist.ForEach(item => Console.WriteLine("RouteID : {0} \n Route From : {1} \n Route To : {2}\n Bus Number : {3} \n Bus Type : {4} \n Capacity {5} \n Fare {6}\n", item.RouteId, item.RouteFrom, item.RouteTo, item.BusNo, item.BusType, item.Capacity, item.Fare));

            }
            catch (RouteExceptions e)
            {
                Console.WriteLine(e.Message);
            }
        }




        static void Main(string[] args)//Main Begins
        {
            int choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your Choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddRoute();
                        break;
                    case 2:
                        SearchRouteByID();
                        break;
                    case 3:
                        UpdateRoute();
                        break;
                    case 4:
                        DeleteRoute();
                        break;
                    case 5:
                        Environment.Exit(0);
                        break;
                    case 6:
                        Deserialization();
                        break;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            } while (choice != -1);
        }


    }
}
