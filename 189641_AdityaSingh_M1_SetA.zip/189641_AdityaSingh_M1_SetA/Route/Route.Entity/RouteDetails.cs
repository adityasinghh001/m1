﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Route.Entity
{
    [Serializable]
    //For Serialization it is a Required Attribute
    public class RouteDetails
    {
        //Adding Properties
        public int RouteId { get; set; }//Route ID
        public string RouteFrom { get; set; }//Source
        public string RouteTo { get; set; }//Destination
        public string BusNo { get; set; }//Bus Number
        public string BusType { get; set; }//Bus Type
        public int Capacity { get; set; }//Bus Capacity
        public int Fare { get; set; }//Fare
    }
}
