﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Route.DataAccessLayer;
using Route.Entity;
using Route.Exceptions;
using System.Text.RegularExpressions;

namespace Route.BusinessLayer
{
    public class RouteBL
    {
        private static bool ValidateRoute(RouteDetails route)//Validation Begins
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                bool validRoute = true;
                //Checking for Empty Parameter
                if ((route.RouteFrom == string.Empty) || (route.RouteTo == string.Empty) || (route.BusNo == string.Empty) || (route.BusType == string.Empty) || (Convert.ToString(route.Capacity).Length == 0) || (Convert.ToString(route.Fare).Length == 0) || (Convert.ToString(route.RouteId).Length == 0))
                {
                    validRoute = false;
                    sb.Append(Environment.NewLine + "No Field Should be left Blank");
                }
                //Checking Route ID length must be greater than or equal to 2 and less than or equal to 3
                if ((Convert.ToString(route.RouteId).Length < 2) || (Convert.ToString(route.RouteId).Length > 3))
                {
                    validRoute = false;
                    sb.Append(Environment.NewLine + "Route Id must be 2 to 3 digit Long");
                }
                //Regex Matching for Bus Number Entry
                if (!Regex.IsMatch(route.BusNo, @"^[a-zA-Z][a-zA-Z][-][0-9][0-9][-][a-zA-z][a-zA-Z][-][0-9][0-9][0-9][0-9]"))
                {
                    validRoute = false;
                    sb.Append(Environment.NewLine + "Please Enter Bus Number in given Format");
                }
                //Checking Ac or Non Ac Bus Type
                if (!((route.BusType == "AC") || (route.BusType == "Non-AC")))
                {
                    validRoute = false;
                    sb.Append(Environment.NewLine + "Please Enter BusType in given Format Only");
                }
                string routeCapacityCheck = Convert.ToString(route.Capacity);
                string routeFareCheck = Convert.ToString(route.Fare);
                //Checking that Capacity and fare are Digits Only
                if (!((Regex.IsMatch(routeCapacityCheck, @"[0-9]") && Regex.IsMatch(routeFareCheck, @"[0-9]"))))
                {
                    validRoute = false;
                    sb.Append(Environment.NewLine + "Please Enter Capacity and Fare in Digits Only");
                }

                if (validRoute == false)
                {
                    throw new RankException(sb.ToString());
                }

                return validRoute;
            }
            catch(RouteExceptions ex)
            {
                throw new RouteExceptions(ex.Message);
            }

        }


        public static bool AddRouteBL(RouteDetails addRoute)//Adding Route in Business Layer Logic
        {
            bool routeAdded = false;
            try
            {
                if (ValidateRoute(addRoute))
                {
                    RouteDAL routeDAL = new RouteDAL();
                    routeAdded = routeDAL.AddNewRoute(addRoute);
                    return routeAdded;
                }
            }
            catch (RouteExceptions ex)
            {
                throw new RouteExceptions(ex.Message);
            }
            return routeAdded;
        }

        public static bool UpdateRouteBL(RouteDetails updateRoute)//Adding Route in Business Layer Logic
        {
            bool routeUpdated = false;
            try
            {
                if (ValidateRoute(updateRoute))
                {
                    RouteDAL routeDAL = new RouteDAL();
                    routeUpdated = routeDAL.UpdateRouteDAL(updateRoute);
                    return routeUpdated;
                }
            }
            catch (RouteExceptions ex)
            {
                throw ex;
            }
            return routeUpdated;
        }

        public static bool DeleteRouteBL(int RouteId)//Deletion of  Route in Business Layer Logic
        {
            bool routeDeleted = false;
            try
            {
                if (RouteId > 0)
                {
                    RouteDAL routeDAL = new RouteDAL();
                    routeDeleted = routeDAL.DeleteRouteDAL(RouteId);
                }
                else
                {
                    throw new RouteExceptions("Route Id must be greater tha 0");
                }
            }
            catch (RouteExceptions ex)

            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return routeDeleted;
        }

        public static RouteDetails SearchRouteBL(int RouteId)//Searching of  Route in Business Layer Logic
        {
            RouteDetails route = null;
            try
            {
                if (RouteId > 0)
                {
                    RouteDAL routeDAL = new RouteDAL();
                    route = routeDAL.SearchRouteDAL(RouteId);
                }
                else
                {
                    throw new RouteExceptions("Route Id must be greater than 0");
                }
            }
            catch (RouteExceptions ex)
            {

                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return route;
        }


        public static bool SerializationBL()//Serialization in Business Layer Logic
        {
            bool serial = false;
            RouteDAL routeDAL = new RouteDAL();
            serial = routeDAL.SerializationDAL();
            return serial;
        }
        public static List<RouteDetails> DeserializationBL()//Deserialization in Business Layer Logic
        {
            RouteDAL objDAL = new RouteDAL();
            List<RouteDetails> deserial = objDAL.DeserializationDAL();
            return deserial;
        }
    }

}
