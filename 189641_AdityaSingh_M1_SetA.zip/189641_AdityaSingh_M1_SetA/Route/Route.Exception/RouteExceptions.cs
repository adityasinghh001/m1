﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Route.Exceptions
{
    //We are handling the Exceptions here
    public class RouteExceptions:ApplicationException//deriving Application Exception Class here
    {
        //All Exceptions Added.
        public RouteExceptions():base()
        {

        }
        public RouteExceptions(string message):base (message)
        {

        }
        public RouteExceptions(string message,Exception innerException):base(message,innerException)
        {

        }
    }
}
