﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Route.Entity;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using Route.Exceptions;

namespace Route.DataAccessLayer
{
    public class RouteDAL
    {
        public static List <RouteDetails> RouteDetail = new List<RouteDetails>();//Creating the list to store the collection
        public bool AddNewRoute(RouteDetails newRoute) //Adding Route Details
        {
            bool routeAdded = false;
            try
            {
                RouteDetail.Add(newRoute);
                routeAdded = true;
            
            }
            catch (RouteExceptions ex)
            {
                throw new RouteExceptions(ex.Message);
            }
            return routeAdded;
        }


        public bool UpdateRouteDAL(RouteDetails updateRoute)//Updation of Route
        {
            bool routeUpdated = false;
            try
            {
                for(int i=0;i<RouteDetail.Count;i++)
                {
                    if(RouteDetail[i].RouteId == updateRoute.RouteId)//Comparing and updating
                    {
                        RouteDetail[i].RouteFrom = updateRoute.RouteFrom;
                        RouteDetail[i].RouteTo = updateRoute.RouteTo;
                        RouteDetail[i].BusNo = updateRoute.BusNo;
                        RouteDetail[i].BusType = updateRoute.BusType;
                        RouteDetail[i].Capacity = updateRoute.Capacity;
                        RouteDetail[i].Fare = updateRoute.Fare;
                        routeUpdated = true;
                        return routeUpdated;
                    }
                }
            }
            catch (RouteExceptions ex)
            {
                throw new RouteExceptions(ex.Message);
            }
            return routeUpdated;
        }


        public bool DeleteRouteDAL(int deleteRouteId)//Deletion of Route
        {
            bool routeDeleted = false;
            try
            {
                RouteDetails deleteDetails = RouteDetail.Find(details => details.RouteId == deleteRouteId);//Finding Route by using Anonymous Function
                RouteDetail.Remove(deleteDetails);
                routeDeleted = true;
                return routeDeleted;
            }
            catch (RouteExceptions ex)
            {
                throw new RouteExceptions(ex.Message);
            }
        }


        public RouteDetails SearchRouteDAL(int searchRouteId)//Route Searching
        {
            RouteDetails searchId = null;
            try
            {
                searchId = RouteDetail.Find(details => details.RouteId == searchRouteId);//Finding Route by using Anonymous Function
                return searchId;
            }
            catch (RouteExceptions ex)
            {
                throw new RouteExceptions(ex.Message);
            }
        }

        public bool SerializationDAL()//Binary Serialization
        {
            bool serializationGuest = false;
            try
            {
                FileStream stream = new FileStream("lab14.bat", FileMode.Create, FileAccess.Write);
                BinaryFormatter binary = new BinaryFormatter();
                binary.Serialize(stream, RouteDetail);
                stream.Close();
                serializationGuest = true;
            }
            catch (RouteExceptions e)
            {
                Console.WriteLine(e.Message);
            }
            return serializationGuest;
        }

        public List<RouteDetails> DeserializationDAL()//Binary Deserialization
        {

            FileStream stream = new FileStream("lab14.bat", FileMode.Open, FileAccess.Read);
            BinaryFormatter binary = new BinaryFormatter();
            List<RouteDetails> objguest = binary.Deserialize(stream) as List<RouteDetails>;
            stream.Close();
            return objguest;

        }
    }
}
