﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MTTWCF_PLayer.MTTWCF_Reference;

namespace MTTWCF_PLayer
{
    public partial class WCF_Page : System.Web.UI.Page
    {
        Service1Client client = null;

        public WCF_Page()
        {
            client = new Service1Client();
        }

        public void clear()
        {
            txtEmpName.Text = txtAddress.Text = txtDOJ.Text = txtSalary.Text = string.Empty;
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    PopulateUI();
                }
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "EMS-Error", "alert('" + ex.Message + "')", true);
            }
        }
        
        public void PopulateUI()
        {
            try
            {
                //List<EmployeeEntity> employees = bal.GetAll();
                List<Employee> IEmps = client.GetAll().ToList();
                List<Employee> employees = IEmps.Select(e => new Employee
                {
                    Empid = e.Empid,
                    empName = e.empName,
                    DoJ = e.DoJ,
                    Salary = e.Salary,
                    Address = e.Address
                }).ToList();
                gvEmps.DataSource = employees;
                gvEmps.DataBind();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            try
            {
                Employee emp = new Employee
                {
                    empName = txtEmpName.Text,
                    DoJ = Convert.ToDateTime(txtDOJ.Text),
                    Salary = Convert.ToDouble(txtSalary.Text),
                    Address = txtAddress.Text
                };
                client.Add(new Employee { empName = emp.empName, DoJ = emp.DoJ, Salary = emp.Salary, Address = emp.Address });
                ScriptManager.RegisterStartupScript(this, this.GetType(), "EMS", "alert('Employee Inserted Successfully!')", true);
                PopulateUI();
                clear();
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "EMS-Error", "alert('" + ex.Message + "')", true);
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                Employee emp = new Employee
                {
                    Empid = Convert.ToInt32(txtEmpid.Text),
                    empName = txtEmpName.Text,
                    DoJ = Convert.ToDateTime(txtDOJ.Text),
                    Salary = Convert.ToDouble(txtSalary.Text),
                    Address = txtAddress.Text                    

                };
                client.Update(new Employee { empName = emp.empName, DoJ = emp.DoJ, Salary = emp.Salary, Address = emp.Address , Empid = emp.Empid });

                ScriptManager.RegisterStartupScript(this, this.GetType(), "EMS", "alert('Employee Updated Successfully!')", true);
                PopulateUI();
                clear();
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "EMS-Error", "alert('" + ex.Message + "')", true);
            }
        }

        protected void btndelete_Click(object sender, EventArgs e)
        {
            try
            {
                Employee emp = new Employee()
                {
                    Empid = Convert.ToInt32(txtEmpid.Text)
                };
                client.Remove(emp.Empid);
                ScriptManager.RegisterStartupScript(this, this.GetType(), "EMS", "alert('Employee Deleted Successfully!')", true);
                PopulateUI();
                clear();
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "EMS-Error", "alert('" + ex.Message + "')", true);
            }
        }

        protected void btnsearch_Click(object sender, EventArgs e)
        {
            try
            {
                //List<EmployeeEntity> employees = bal.GetAll();
                Employee IEmps = client.Search(Convert.ToInt32(txtEmpid.Text));
                txtEmpid.Text = IEmps.Empid.ToString();
                txtEmpName.Text = IEmps.empName.ToString();
                txtDOJ.Text = IEmps.DoJ.ToString("yyyy-MM-dd");
                txtSalary.Text = IEmps.Salary.ToString();
                txtAddress.Text = IEmps.Address.ToString();
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}