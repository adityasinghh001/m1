﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using WebAPI_ForTesting.Models;

namespace WebAPI_ForTesting.Controllers
{
    public class EmployeesController : ApiController
    {
        List<Employee> emps = new List<Employee>
            {
                new Employee { EmpId = 101, EmpName = "Harish P", DOJ = new DateTime(2019, 2, 3), Salary = 454500 },
                new Employee { EmpId = 102, EmpName = "Jaya L", DOJ = new DateTime(2014, 7, 23), Salary = 565421 },
                new Employee { EmpId = 103, EmpName = "Lakshmikumar", DOJ = new DateTime(2016, 2, 19), Salary = 563342 }
            };

        public IEnumerable<Employee> Get()
        {           
            return emps;
        }

        [System.Web.Http.HttpPost]
        public void Post(Employee emp)
        {
            emps.Add(emp);
        }
    }
}
