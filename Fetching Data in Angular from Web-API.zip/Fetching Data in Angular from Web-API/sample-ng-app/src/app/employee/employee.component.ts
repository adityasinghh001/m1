
import {Component, Input} from '@angular/core'
import { IEmployee } from './employee';
import { EmployeeService } from 'src/services/employeeService.service';
import { getAllLifecycleHooks } from '@angular/compiler/src/lifecycle_reflector';

@Component({
  selector: 'emp-details',
  templateUrl: './employee.component.html'
})
export class EmployeeComponent
{

    private eNameFilter: string
    get ENameFilter(): string{
      return this.eNameFilter;
    }
    set ENameFilter(value: string)
    {
      this.eNameFilter = value;
    }

    constructor(private employees: EmployeeService){}
    message: string = 'This is from Employee Component-2'

    AllEmpCount(): number
    {
      return this.employees.GetAllEmployees().length;
    }

    SalaryLT40KCount(): number
    {
      return this.employees.GetAllEmployees().filter(e => e.Salary < 40000).length;
    }

    SalaryGT40K()
    {
      return this.employees.GetAllEmployees().filter(e => e.Salary>= 40000).length;
    }


    M1() {
      return "From M1 method"
    }

    GetEmployees(): IEmployee[]
    {
      var emps = this.employees.GetAllEmployees();
      if(this.eNameFilter)
      {
        return emps.filter(e => e.EmpName.toLowerCase().indexOf(this.ENameFilter.toLowerCase()) !== -1)
      }
      else{
        return emps;
      }


    }

    private toggle : boolean = true
    ToggleShow()
    {
        (this.toggle)? this.toggle = false : this.toggle = true;
    }

    Show() : boolean
    {
      return this.toggle;
    }
}
