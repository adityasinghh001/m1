export interface IEmployee
{
  EmpId: number
  EmpName: string
  DOJ: Date
  Salary: number
}

// class Employee{

// }
