import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'emp-filter',
  templateUrl: './empFilter.component.html'
})
export class EmpFilter
{
  @Input()
  all : number = 0;
  @Input()
  lt40k: number = 0;
  @Input()
  gt40K: number = 0;

    selectedFilterNumber: number

    @Output()
    filterSelectionChanged: EventEmitter<number> = new EventEmitter<number>();

    onSelectedFilterNumber()
    {
       this.filterSelectionChanged.emit(this.selectedFilterNumber);
    }

}
