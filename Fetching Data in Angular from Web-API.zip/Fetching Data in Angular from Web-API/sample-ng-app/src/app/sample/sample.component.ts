import { Component, OnInit } from '@angular/core';
import { EmployeeService } from 'src/services/employeeService.service';

@Component({
  selector: 'app-sample',
  templateUrl: './sample.component.html',
  styleUrls: ['./sample.component.css'],
  providers: [EmployeeService]
})
export class SampleComponent implements OnInit {

  constructor(private loggerService: EmployeeService) { }

  ngOnInit() {
    //this.loggerService.log('Service Class is Initialized!')
  }

}
