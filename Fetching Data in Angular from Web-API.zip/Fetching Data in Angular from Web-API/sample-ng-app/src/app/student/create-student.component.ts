import { Component, OnInit } from "@angular/core";
import { FormGroup, FormControl } from '@angular/forms';

@Component
({
  selector: 'app-create-student',
  templateUrl:'/create-student.component.html'
})
export class CreateStudent implements OnInit
{
  studForm: FormGroup;

  ngOnInit(): void {
    this.studForm = new FormGroup({
      rollNo : new FormControl(),
      studName : new FormControl(),
      emailId : new FormControl()
     });
  }

  onSubmit()
  {
     console.log(this.studForm.value);
  }

}
