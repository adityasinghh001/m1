import {  Injectable } from '@angular/core';
import { IEmployee } from 'src/app/employee/employee';
import {HttpClient} from '@angular/common/http';

@Injectable({ providedIn : 'root' })
export class EmployeeService
{
  constructor(private http: HttpClient) {

  }

  emps : IEmployee[];

  GetAllEmployees(): IEmployee[]
  {
    //use URL for local json file :
    //this.http.get<IEmployee[]>('http://localhost:4200/assets/emps.json')
    this.http.get<IEmployee[]>('http://localhost:50247/api/Employees/')
     .subscribe(e => this.emps = e);
     return this.emps;
  }

}
