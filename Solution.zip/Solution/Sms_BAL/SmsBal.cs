﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMSException;
using Sms_Entities;
using Sms_Dal;

namespace Sms_BAL
{
    public class SmsBal
    {
        public void add(StudentEntities student)
        {
            SmsDal studentdal = new SmsDal();
            studentdal.insert(student);
        }
        public void modify(StudentEntities student)
        {
            SmsDal studentdal = new SmsDal();
            studentdal.update(student);
        }
    }
}
