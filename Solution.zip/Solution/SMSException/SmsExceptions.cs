﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMSException
{
    public class SmsExceptions : ApplicationException//deriving Application Exception Class here
    {
        //All Exceptions Added.
        public SmsExceptions() : base()
        {

        }
        public SmsExceptions(string message) : base(message)
        {

        }
        public SmsExceptions(string message, Exception innerException) : base(message, innerException)
        {

        }
    }
}
