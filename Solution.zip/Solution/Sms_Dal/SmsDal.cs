﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sms_Entities;
using System.Data.SqlClient;
using SMSException;

namespace Sms_Dal
{
    public class SmsDal
    {
        SqlCommand cmd = null;
        SqlConnection cn = null;
        SqlDataReader dr = null;
        public SmsDal()
        {
            cn = new SqlConnection(@"Data Source=ndamssql\sqlilearn;Initial Catalog=Training_18Jul19_Pune;Persist Security Info=True;User ID=sqluser;Password=sqluser");

        }


        public void insert(StudentEntities student)
        {
            cmd = new SqlCommand("insert into ad189641.Student values (@fullName,@gender,@dob,@mobNumber,@email,@state,@add)", cn);
            //cmd.Parameters.AddWithValue("@SRollNo", student.RollNumber);
            cmd.Parameters.AddWithValue("@fullName", student.StudentFullName);
            cmd.Parameters.AddWithValue("@gender", student.Gender);
            cmd.Parameters.AddWithValue("@dob", student.DateOfBirth);
            cmd.Parameters.AddWithValue("@mobNumber", student.MobileNumber);
            cmd.Parameters.AddWithValue("email", student.EmailAdress);
            cmd.Parameters.AddWithValue("@state", student.State);
            cmd.Parameters.AddWithValue("@add", student.CommunicationAddress);
            // cmd.Parameters.AddWithValue("@fullName", student.StudentFullName);
            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();
        }
        public void update(StudentEntities student)
        {
            cmd = new SqlCommand("insert into ad189641.Student values (@fullName,@gender,@dob,@mobNumber,@email,@state,@add)", cn);
            //cmd.Parameters.AddWithValue("@SRollNo", student.RollNumber);
            cmd.Parameters.AddWithValue("@fullName", student.StudentFullName);
            cmd.Parameters.AddWithValue("@gender", student.Gender);
            cmd.Parameters.AddWithValue("@dob", student.DateOfBirth);
            cmd.Parameters.AddWithValue("@mobNumber", student.MobileNumber);
            cmd.Parameters.AddWithValue("email", student.EmailAdress);
            cmd.Parameters.AddWithValue("@state", student.State);
            cmd.Parameters.AddWithValue("@add", student.CommunicationAddress);
            // cmd.Parameters.AddWithValue("@fullName", student.StudentFullName);
            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();
        }

        public StudentEntities selectByRollNo(int rollNo)
        {
            try
            {
                cmd = new SqlCommand("select * from StudentEntities where rollNo=@r", cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                if(dr.Read())
                {

                }
            }
            catch(Exception)
            {
                throw;
            }
            finally
            {
                dr.Close();
                cn.Close();
            }
            return 
        }
    }
    }
   
 