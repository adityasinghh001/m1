﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sms_Entities
{
    public class StudentEntities
    {

        //Adding Properties
      //  public int RollNumber { get; set; }
        public string StudentFullName { get; set; }
        public string Gender { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string MobileNumber { get; set; }
        public string EmailAdress { get; set; }
        public string CommunicationAddress { get; set; }
        public string State { get; set; }
    }
}

   