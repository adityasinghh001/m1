﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;

namespace LinqToData_Demo
{
    class Program
    {
        //Method returning dataset by retriving records from db & filling it into dataset
        static DataSet GetDataSet()
        {            
            SqlConnection con = new SqlConnection(@"Data Source=ndamssql\sqlilearn;Initial Catalog=Training;User ID=sqluser;Password=sqluser");            
            SqlCommand cmd = new SqlCommand("select * from amol.Employee", con);
            DataSet ds = new DataSet();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(ds, "Emp");
            return ds;
        }
        static void Main(string[] args)
        {                        
            //Obtaining the data source on which to write LINQ
            var empDataSource = GetDataSet().Tables["Emp"].AsEnumerable();

            ////Sample-#1
            ////LINQ query to get employees having salary greater than 38000
            //var query = from r in empDataSource
            //            where r.Field<decimal>("Salary") > 38000
            //            orderby r.Field<decimal>("Salary")
            //            select r;                        

            ////executing the query to retrive the LINQ result
            //foreach (var row in query)
            //{
            //    string str = $"EmpId: {row["EmpId"]}, Name: {row["EmpName"]}, Salary: {row["Salary"]}";
            //    Console.WriteLine(str);
            //}

            ////Sample-#2
            //var query = from recEmp in empDataSource
            //            where recEmp.Field<DateTime>("DOJ").Year == 2003
            //            select new
            //            {
            //                EmpId = recEmp.Field<int>("EmpId"),
            //                EmpName = recEmp.Field<string>("EmpName"),
            //                Gender = recEmp.Field<string>("Gender"),
            //                DOJ = recEmp.Field<DateTime>("DOJ")
            //            };
            //foreach (var emp in query)
            //{
            //    var strEmp = $"EmpId: {emp.EmpId}, Name: {emp.EmpName}, Gender: {emp.Gender}, DOJ: {emp.DOJ}";
            //    Console.WriteLine(strEmp);
            //}

            //Sample-#3
            var query = from recEmp in empDataSource
                        where recEmp.Field<string>("Gender") == "Male"
                        orderby recEmp.Field<DateTime>("DOJ")
                        select new
                        {
                            EmpId = recEmp.Field<int>("EmpId"),
                            EmpName = recEmp.Field<string>("EmpName"),
                            Gender = recEmp.Field<string>("Gender"),
                            DOJ = recEmp.Field<DateTime>("DOJ")
                        };
            foreach (var emp in query)
            {
                var strEmp = $"EmpId: {emp.EmpId}, Name: {emp.EmpName}, Gender: {emp.Gender}, DOJ: {emp.DOJ}";
                Console.WriteLine(strEmp);
            }

            ////Loading the query results into DataTable object.
            //DataTable table = query.CopyToDataTable();

            Console.ReadKey();
        }
    }
}
