﻿
create table LINQ.Employee(
	EmployeeID int,
	FirstName varchar(20),
	LastName varchar(20),
	Title varchar(20),
	DOB datetime,
	DOJ datetime,
	City varchar(20)
);

insert into LINQ.Employee values 
(1001, 'Malcolm', 'Daruwalla','Manager','11/16/1984','6/8/2011','Mumbai'),
(1002,'Asdin','Dhalla','AsstManager','08/20/1984','7/7/2012','Mumbai'),
(1003,'Madhavi','Oza','Consultant','11/14/1987','4/12/2015','Pune'),
(1004,'Saba', 'Shaikh','SE','6/3/1990','2/2/2016','Pune'),
(1005,'Nazia', 'Shaikh','SE','3/8/1991','2/2/2016','Mumbai'),
(1006,'Suresh', 'Pathak','Consultant','11/7/1989','8/8/2014','Chennai'),
(1007,'Vijay', 'Natrajan','Consultant','12/2/1989','6/1/2015','Mumbai'),
(1008,'Rahul', 'Dubey','Associate','11/11/1993','11/6/2014','Chennai'),
(1009,'Amit', 'Mistry','Associate','8/12/1992','12/3/2014','Chennai'),
(1010,'Sumit', 'Shah','Manager','4/12/1991','1/2/2016','Pune');

select * from LINQ.Employee 
