﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqToData_Demo
{
    class Emp { public DateTime DOB { get; set; } }
    class LabBookSolutions
    {
        static DataSet GetDataSet()
        {
            SqlConnection con = new SqlConnection(@"Data Source=ndamssql\sqlilearn;Initial Catalog=Training;User ID=sqluser;Password=sqluser");
            SqlCommand cmd = new SqlCommand("select * from LINQ.Employee", con);
            DataSet ds = new DataSet();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(ds, "Emp");
            return ds;
        }
        static void Main(string[] args)
        {
            ////#1 - Sort & Display Employee by their Joining Year in ascending order & then by their First-Name in descending order
            //var sortedEmps = from e in GetDataSet().Tables["Emp"].AsEnumerable()
            //                 orderby e.Field<DateTime>("DOJ").Year//, e.Field<string>("FirstName")
            //                 select e;
            //foreach (var emp in sortedEmps)
            //{
            //    Console.WriteLine($"EmpId: {emp.Field<int>("EmployeeID")}, First-Name: {emp.Field<string>("FirstName")}, Last-Name: {emp.Field<string>("LastName")}, Joining-Year: {emp.Field<DateTime>("DOJ").Year}");
            //}

            ////#2 - Get Average Age in Years (Ex-32.87) of Manager Employees
            //var avgAge = (from e in GetDataSet().Tables["Emp"].AsEnumerable()
            //                where e.Field<string>("Title") == "Manager"
            //                select( DateTime.Now.Subtract( e.Field<DateTime>("DOB"))).TotalDays / 365.0).ToList().Average();
            //Console.WriteLine($"Average Age of AsstManager & Manager Employees in Year is : "+ avgAge.ToString("0.##"));

            ////#3 - Group Employees by their City in such way that younger Employees will be displayed on top
            //var empGroup = from e in GetDataSet().Tables["Emp"].AsEnumerable()
            //               orderby e.Field<DateTime>("DOB")
            //               group e by e.Field<string>("City");
            //foreach (var grp in empGroup)
            //{
            //    Console.WriteLine("\t" + grp.Key + " Employees");
            //    foreach (var e in grp)
            //    {
            //        Console.WriteLine($"EmpId: {e.Field<int>("EmployeeID")}, First-Name: {e.Field<string>("FirstName")}, Last-Name: {e.Field<string>("LastName")}, DOB: {e.Field<DateTime>("DOB")}");
            //    }
            //}

            Console.ReadKey();
        }
    }
}
