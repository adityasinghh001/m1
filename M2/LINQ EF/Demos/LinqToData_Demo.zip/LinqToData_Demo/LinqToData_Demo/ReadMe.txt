﻿* SQL Script for Table creation

CREATE TABLE [dbo].[Employee] (
    [EmpId]   INT          NOT NULL,
    [EmpName] VARCHAR (20) NULL,
    [DeptId]  INT          NULL,
    [Salary]  MONEY        NULL,
    PRIMARY KEY CLUSTERED ([EmpId] ASC)
);

