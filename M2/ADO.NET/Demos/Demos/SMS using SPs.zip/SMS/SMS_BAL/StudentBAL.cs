﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SMS_DAL;
using SMS_Entities;

namespace SMS_BAL
{
    public class StudentBAL
    {
        StudentDAL dal = new StudentDAL();
        public int Add(Student student)
        {
            int rollNo;
            try
            {
                rollNo = dal.Insert(student);
            }
            catch(Exception)
            {
                throw;
            }
            return rollNo;
        }

        public Student GetBy(int rollNo)
        {
            Student student = null;
            try
            {
                student = dal.SelectBy(rollNo);
            }
            catch (Exception ex1)
            {
                throw ex1;
            }
            return student;
        }

        public List<Student> GetAll()
        {
            List<Student> students = null;
            try
            {
                students = dal.SelectAll();
            }
            catch (Exception ex1)
            {
                throw ex1;
            }
            return students;
        }

        public void Modify(Student student)
        {
            try
            {
                dal.Update(student);
            }
            catch(Exception)
            {
                throw;
            }
        }
    }
}
