﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ado_DiscArch_Demo
{
    class Student
    {
        public int RollNo { get; set; }
        public string FullName { get; set; }
    }
}
