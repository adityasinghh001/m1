﻿
create table Product
(
	Id int primary key,
	ProdName varchar(20),
	Price money,
	ExpDate date
)


