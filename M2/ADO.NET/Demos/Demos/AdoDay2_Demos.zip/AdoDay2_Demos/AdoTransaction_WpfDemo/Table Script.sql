﻿	
create table BankAccount
(
	AccNo int primary key,
	AccHolderName varchar(20),
	CurBalance money
)


