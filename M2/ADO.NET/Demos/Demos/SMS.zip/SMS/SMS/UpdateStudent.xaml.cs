﻿using SMS_BAL;
using SMS_Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SMS
{
    /// <summary>
    /// Interaction logic for UpdateStudent.xaml
    /// </summary>
    public partial class UpdateStudent : Window
    {

        //try
        //{

        //}
        //catch(Exception ex1)
        //{
        //    MessageBox.Show(ex1.Message);
        //}

        StudentBAL bal = new StudentBAL();
        public UpdateStudent()
        {
            InitializeComponent();
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int rollNo = int.Parse(txtRollNo.Text);
                Student student = bal.GetBy(rollNo);
                txtRollNo.Text = student.RollNo.ToString();
                txtFullName.Text = student.FullName;
                if( student.Gender == "Male")
                {
                    rbMale.IsChecked = true;
                }
                else if (student.Gender == "Female")
                {
                    rbFemale.IsChecked = true;
                }
                txtDOB.Text = student.DOB.ToString();
                txtMobNo.Text = student.MobileNo;
                txtEmail.Text = student.Email;
                foreach (ListBoxItem lbi in lbState.Items)
                {
                    if (lbi.Content.ToString() == student.State)
                        lbi.IsSelected = true;
                }
                txtAddress.Document.Blocks.Clear();
                txtAddress.Document.Blocks.Add(new Paragraph(new Run(student.Address)));
            }
            catch (Exception ex1)
            {
                MessageBox.Show(ex1.Message);
            }

            
        }

     

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                List<Student> studs = bal.GetAll();
                dgStudents.ItemsSource = studs;
            }
            catch (Exception ex1)
            {
                MessageBox.Show(ex1.Message);
            }           
        }
    }
}
